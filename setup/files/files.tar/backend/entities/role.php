<?php

class Role extends RoleCache
{

	const ROLE_ADMIN = 'ADMIN';

	public function role_has_any_permission($role, $arg1, $arg2=null)
	{
		if(!($role && is_object($role) && $role instanceof Role))
		{
			$role = self::get_id_role($role);
		}

		if($role)
		{
			$args = func_get_args();
			$args = array_slice($args, 1);

			return call_user_func_array(array($role, 'has_any_permissions'), $args);
		}
		else
		{
			return false;
		}
	}

	public function role_has_all_permission($role, $arg1, $arg2=null)
	{
		if(!($role && is_object($role) && $role instanceof Role))
		{
			$role = self::get_id_role($role);
		}

		if($role)
		{
			$args = func_get_args();
			$args = array_slice($args, 1);

			return call_user_func_array(array($role, 'has_all_permissions'), $args);
		}
		else
		{
			return false;
		}
	}


	public function has_any_permissions($arg1, $arg2=null)
	{
		if($this->get_is_admin())
		{
			return true;
		}

		$args = func_get_args();
		$permissions = call_user_func_array(array('Permission', 'parse_list'), $args);

		if(empty($permissions))
		{
			return true;
		}

		foreach($permissions as $permission)
		{
			if(RolePermission::count_all(array('id_role' => $this->get_id_role(), 'id_permission' => $permission->get_id_permission())))
			{
				return true;
			}
		}

		return false;
	}

	public function has_all_permissions($arg1, $arg2=null)
	{
		if($this->get_is_admin())
		{
			return true;
		}

		$args = func_get_args();
		$permissions = call_user_func_array(array('Permission', 'parse_list'), $args);

		if(empty($permissions))
		{
			return true;
		}

		foreach($permissions as $permission)
		{
			if(!RolePermission::count_all(array('id_role' => $this->get_id_role(), 'id_permission' => $permission->get_id_permission())))
			{
				return false;
			}
		}

		return true;
	}

	public function is_admin()
	{
		return $this->get_is_admin();
	}

	/* ZPHP Generated Code ------------------------------------------ */
	/* /ZPHP Generated Code ------------------------------------------ */

}

