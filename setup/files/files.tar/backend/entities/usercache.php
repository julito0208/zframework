<?php

class UserCache extends UserDatabase
{

	/* ZPHP Generated Code ------------------------------------------ */


	protected static $_CACHE_MANAGER_KEY_GET_PREFIX = "cache_userentity_get_by_";

	protected static function _generate_cache_key_get_by_id_user($id_user) {
		$values = func_get_args();
		return self::$_CACHE_MANAGER_KEY_GET_PREFIX.'id_user_'.implode('_', $values);
	}

	protected static function _generate_cache_key_get_by_username($username) {
		$values = func_get_args();
		return self::$_CACHE_MANAGER_KEY_GET_PREFIX.'username_'.implode('_', $values);
	}

	protected static function _cache_save($entity) {
		if($entity) {
			CacheManager::save(self::_generate_cache_key_get_by_id_user($entity->get_id_user()), $entity);
			CacheManager::save(self::_generate_cache_key_get_by_username($entity->get_username()), $entity);
		}
	}

	protected static function _cache_delete($entity) {
		if($entity) {
			CacheManager::delete(self::_generate_cache_key_get_by_id_user($entity->get_id_user()));
			CacheManager::delete(self::_generate_cache_key_get_by_username($entity->get_username()));
		}
	}

	
	/**
	* @return User
	*/
	public static function get_by_id_user($id_user, $column=null) {
		$entity = CacheManager::get(self::_generate_cache_key_get_by_id_user($id_user));

		if(!$entity) {
			$entity = parent::get_by_id_user($id_user);
			if($entity) self::_cache_save($entity);
		}

		return ($entity && $column) ? $entity->$column : $entity;
	}
	
	/**
	* @return User
	*/
	public static function get_by_username($username, $column=null) {
		$entity = CacheManager::get(self::_generate_cache_key_get_by_username($username));

		if(!$entity) {
			$entity = parent::get_by_username($username);
			if($entity) self::_cache_save($entity);
		}

		return ($entity && $column) ? $entity->$column : $entity;
	}


	public static function saveEntity(User $entity) {
		parent::saveEntity($entity);
		self::_cache_save($entity);
	}
	
	
	public static function delete_by_id_user($id_user) {

		$conditions = array();
		$conditions['id_user'] = $id_user;
		return User::delete_rows($conditions);

	}
	
	
	public static function delete_by_username($username) {

		$conditions = array();
		$conditions['username'] = $username;
		return User::delete_rows($conditions);

	}
	
	
	public static function delete_rows($conditions=array()) {
		$rows = self::list_all($conditions);
		foreach($rows as $row){
			self::_cache_delete($row);
		}
		parent::delete_rows($conditions);
	}

	/* /ZPHP Generated Code ------------------------------------------ */

}

