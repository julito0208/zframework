<?php

class UserRoleCache extends UserRoleDatabase
{

	/* ZPHP Generated Code ------------------------------------------ */


	protected static $_CACHE_MANAGER_KEY_GET_PREFIX = "cache_userroleentity_get_by_";

	protected static function _generate_cache_key_get_by_id_user_id_role($id_user, $id_role) {
		$values = func_get_args();
		return self::$_CACHE_MANAGER_KEY_GET_PREFIX.'id_user_id_role_'.implode('_', $values);
	}

	protected static function _cache_save($entity) {
		if($entity) {
			CacheManager::save(self::_generate_cache_key_get_by_id_user_id_role($entity->get_id_user(), $entity->get_id_role()), $entity);
		}
	}

	protected static function _cache_delete($entity) {
		if($entity) {
			CacheManager::delete(self::_generate_cache_key_get_by_id_user_id_role($entity->get_id_user(), $entity->get_id_role()));
		}
	}

	
	/**
	* @return UserRole
	*/
	public static function get_by_id_user_id_role($id_user, $id_role, $column=null) {
		$entity = CacheManager::get(self::_generate_cache_key_get_by_id_user_id_role($id_user, $id_role));

		if(!$entity) {
			$entity = parent::get_by_id_user_id_role($id_user, $id_role);
			if($entity) self::_cache_save($entity);
		}

		return ($entity && $column) ? $entity->$column : $entity;
	}


	public static function saveEntity(UserRole $entity) {
		parent::saveEntity($entity);
		self::_cache_save($entity);
	}
	
	
	public static function delete_by_id_user_id_role($id_user, $id_role) {

		$conditions = array();
		$conditions['id_user'] = $id_user;
		$conditions['id_role'] = $id_role;
		return UserRole::delete_rows($conditions);

	}
	
	
	public static function delete_by_id_user($id_user) {

		$conditions = array();
		$conditions['id_user'] = $id_user;
		return UserRole::delete_rows($conditions);

	}
	
	
	public static function delete_by_id_role($id_role) {

		$conditions = array();
		$conditions['id_role'] = $id_role;
		return UserRole::delete_rows($conditions);

	}
	
	
	public static function delete_rows($conditions=array()) {
		$rows = self::list_all($conditions);
		foreach($rows as $row){
			self::_cache_delete($row);
		}
		parent::delete_rows($conditions);
	}

	/* /ZPHP Generated Code ------------------------------------------ */

}

