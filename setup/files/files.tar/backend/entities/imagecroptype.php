<?php

class ImageCropType extends ImageCropTypeCache
{

	const TYPE_FILL = 'fill';
	const TYPE_FIT = 'fit';
	const TYPE_NONE = 'none';

	/* ZPHP Generated Code ------------------------------------------ */
	/* /ZPHP Generated Code ------------------------------------------ */

}

