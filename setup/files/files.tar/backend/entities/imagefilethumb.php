<?php

class ImageFileThumb extends ImageFileThumbCache
{

	public function get_path()
	{
		$image_file = ImageFile::get_by_id_image_file($this->id_image_file);
		return $image_file->get_path($this->get_id_image_thumb_type());
	}

	public function get_url($image_thumb_type=null)
	{
		$image_file = ImageFile::get_by_id_image_file($this->id_image_file);
		return $image_file->get_url($this->get_id_image_thumb_type());
	}


	public static function delete_rows($conditions)
	{
		$images_files = self::list_all($conditions);

		foreach($images_files as $image_file)
		{
			$path = $image_file->get_path();
			@ unlink($path);
		}

		return parent::delete_rows($conditions);
	}

	/* ZPHP Generated Code ------------------------------------------ */
	/* /ZPHP Generated Code ------------------------------------------ */

}

