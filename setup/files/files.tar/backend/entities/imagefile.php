<?php

class ImageFile extends ImageFileCache
{

	protected static $_default_type = 'png';

	public function get_path($image_thumb_type=null)
	{
		$path_format = ZPHP::get_config('image_path_format');

		$image_thumb_type = ImageThumbType::parse_entity($image_thumb_type);

		if($image_thumb_type)
		{
			return sprintf($path_format, $this->get_id_image_file().'-'.$image_thumb_type->get_id_image_thumb_type(), self::$_default_type);
		}
		else
		{
			return sprintf($path_format, $this->get_id_image_file(), self::$_default_type);
		}
	}

	public function get_url($image_thumb_type=null)
	{
		$path_format = ZPHP::get_config('image_url_format');

		$image_thumb_type = ImageThumbType::parse_entity($image_thumb_type);

		if($image_thumb_type)
		{
			return sprintf($path_format, $this->get_id_image_file().'-'.$image_thumb_type->get_id_image_thumb_type(), self::$_default_type);
		}
		else
		{
			return sprintf($path_format, $this->get_id_image_file(), self::$_default_type);
		}
	}

	/*
	 * @return ImageFile
	 */
	public static function create_image_file(Image $image, $id_group=null)
	{
		$image_file = new ImageFile();
		$image_file->set_date_added(Date::now());
		$image_file->set_height($image->get_height());
		$image_file->set_width($image->get_width());
		$image_file->set_id_group($id_group);
		$image_file->set_title('');
		$image_file->set_id_image_file(uniqid());

		$images_files = ImageFile::list_all(array('id_group' => $id_group), 'pos DESC', 1);

		if(!empty($images_files))
		{
			$image_file->set_pos($images_files[0]->get_pos()+1);
		}
		else
		{
			$image_file->set_pos(0);
		}

		ImageFile::saveEntity($image_file);

		$image->save_copy($image_file->get_path());

		return $image_file;
	}

	public static function delete_rows($conditions)
	{
		$id_images_files = [];

		$images_files = self::list_all($conditions);

		foreach($images_files as $image_file)
		{
			$path = $image_file->get_path();
			@ unlink($path);

			$id_images_files[] = $image_file->id_image_file;
		}

		ImageFileThumb::delete_rows(array('id_image_file' => $id_images_files));

		return parent::delete_rows($conditions);
	}

	/* ZPHP Generated Code ------------------------------------------ */
	/* /ZPHP Generated Code ------------------------------------------ */

}

