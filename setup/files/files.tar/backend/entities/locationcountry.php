<?php

class LocationCountry extends LocationCountryCache
{

	/* ZPHP Generated Code ------------------------------------------ */
	/* /ZPHP Generated Code ------------------------------------------ */

}

