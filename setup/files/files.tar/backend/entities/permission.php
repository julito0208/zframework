<?php

class Permission extends PermissionCache
{

	const PERMISSION_EDIT_BUSINESS = 'EDIT-BUSINESS';
	const PERMISSION_DELETE_BUSINESS = 'DELETE-BUSINESS';
	const PERMISSION_CREATE_CONTACT = 'CREATE-CONTACT';
	const PERMISSION_EDIT_CONTACT = 'EDIT-CONTACT';
	const PERMISSION_EDIT_CONTACT_OTHERS = 'EDIT-CONTACT-OTHERS';

	/*
	 * @return Permission[]
	 */
	public static function parse_list($arg1, $arg2=null)
	{
		$args = func_get_args();
		$permissions = array();

		foreach((array) $args as $arg)
		{
			if($arg && is_array($arg))
			{
				$permissions = array_merge($permissions, call_user_func_array(array('Permission', 'parse_list'), $arg));
			}
			else if($arg && is_object($arg) && $arg instanceof Permission)
			{
				$permissions[] = $arg;
			}
			else if($arg)
			{
				$permission = Permission::get_by_id_permission($arg);

				if($permission)
				{
					$permissions[] = $permission;
				}
			}
		}

		return $permissions;
	}


	/* ZPHP Generated Code ------------------------------------------ */
	/* /ZPHP Generated Code ------------------------------------------ */

}

