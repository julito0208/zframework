<?php

class ImageThumbType extends ImageThumbTypeCache
{

	const TYPE_DEFAULT = 'default';

	public function resize_image(Image $image)
	{
		if($this->get_id_image_crop_type() == ImageCropType::TYPE_FILL)
		{
			$image->fill_canvas_size($this->get_crop_width(), $this->get_crop_height());
		}
		else if($this->get_id_image_crop_type() == ImageCropType::TYPE_FIT)
		{
			$image->fit_canvas_size($this->get_crop_width(), $this->get_crop_height());
		}
		else
		{
			$image->scale($this->get_crop_width(), $this->get_crop_height());
		}
	}

	/* ZPHP Generated Code ------------------------------------------ */
	/* /ZPHP Generated Code ------------------------------------------ */

}

