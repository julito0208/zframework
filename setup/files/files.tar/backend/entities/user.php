<?php

class User extends UserCache
{

	protected static $_SESSION_VARNAME = '__logged_user__';
	protected static $_SESSION_COOKIE_VARNAME = '__logged_cookie_user__';

	protected static $_COOKIE_VARNAME = '__cookie_user__';
	protected static $_COOKIE_DAYS = 365;

	public static function login_user(User $user, $remember=false)
	{
		$user->update_last_login();
		$user->save();

		SessionHelper::remove_var(self::$_SESSION_VARNAME);

		$session = array(
			'user' => $user,
		);

		if($remember)
		{
			$cookie_time = time() + (self::$_COOKIE_DAYS * 24 * 60 * 60);
			NavigationHelper::cookie_add(self::$_COOKIE_VARNAME, $user->get_id_user(), $cookie_time);
		}

		SessionHelper::add_var(self::$_SESSION_VARNAME, $session);
		SessionHelper::add_var(self::$_SESSION_COOKIE_VARNAME, true);
	}


	/**
	 * @return User
	 */
	public static function get_logged_user()
	{
		$user = null;

		if (SessionHelper::has_var(self::$_SESSION_VARNAME))
		{
			$session = SessionHelper::get_var(self::$_SESSION_VARNAME);
			$user = $session['user'];
		}
		else if (!SessionHelper::get_var(self::$_SESSION_COOKIE_VARNAME) && $_COOKIE[self::$_COOKIE_VARNAME])
		{
			$id_user = $_COOKIE[self::$_COOKIE_VARNAME];
			$user = User::get_by_id_user($id_user);

		}

		SessionHelper::add_var(self::$_SESSION_COOKIE_VARNAME, true);

		return $user;
	}


	public static function has_logged_user()
	{
		return (bool) self::get_logged_user();
	}

	public static function logout_user()
	{
		if(self::has_logged_user())
		{
			SessionHelper::remove_var(self::$_SESSION_VARNAME);
			SessionHelper::add_var(self::$_SESSION_COOKIE_VARNAME, true);
		}
	}

	public static function logged_user_has_any_permissions($arg1, $arg2=null)
	{
		$args = func_get_args();
		$permissions = call_user_func_array(array('Permission', 'parse_list'), $args);

		if(empty($permissions))
		{
			return true;
		}

		$user = self::get_logged_user();

		if($user)
		{
			return call_user_func_array(array($user, 'has_any_permissions'), $permissions);
		}
		else
		{
			return false;
		}
	}

	public static function logged_user_has_all_permissions($arg1, $arg2=null)
	{
		$args = func_get_args();
		$permissions = call_user_func_array(array('Permission', 'parse_list'), $args);

		if(empty($permissions))
		{
			return true;
		}

		$user = self::get_logged_user();

		if($user)
		{
			return call_user_func_array(array($user, 'has_all_permissions'), $permissions);
		}
		else
		{
			return false;
		}
	}

	public static function logged_user_is_admin()
	{
		$user = self::get_logged_user();

		if($user)
		{
			return $user->is_admin();
		}
		else
		{
			return false;
		}
	}

	public static function get_logout_url()
	{
		return HTMLPageUserLogout::get_logout_url();
	}

	/*-------------------------------------------------------------------*/

	public static function crypt_password($password)
	{
		return sha1($password);
	}

	/*-------------------------------------------------------------------*/

	public function set_password($password)
	{
		if(!$this->__fromDatabase)
		{
			$password = self::crypt_password($password);
		}

		parent::set_password($password);
	}

	public function update_last_login($date=null)
	{
		if(!$date)
		{
			$date = Date::now();
		}

		$this->set_last_login($date);
	}


	public function login($remember=false)
	{
		self::login_user($this,$remember);
	}

	public function has_any_permissions($arg1, $arg2=null)
	{
		$user_roles = UserRole::list_by_id_user($this->id_user);
		$args = func_get_args();

		foreach($user_roles as $user_role)
		{
			$role = Role::get_by_id_role($user_role->id_role);

			if($role->has_any_permissions($args))
			{
				return true;
			}
		}

		return false;
	}

	public function has_all_permissions($arg1, $arg2=null)
	{
		$user_roles = UserRole::list_by_id_user($this->id_user);
		$args = func_get_args();

		foreach($user_roles as $user_role)
		{
			$role = Role::get_by_id_role($user_role->id_role);

			if(!$role->has_any_permissions($args))
			{
				return false;
			}
		}

		return true;
	}


	public function is_admin()
	{
		$user_roles = UserRole::list_by_id_user($this->id_user);

		foreach($user_roles as $user_role)
		{
			$role = Role::get_by_id_role($user_role->id_role);

			if($role->is_admin())
			{
				return true;
			}
		}

		return false;
	}


	public function check_password($password)
	{
		return self::crypt_password($password) == $this->get_password();
	}
	
	/* ZPHP Generated Code ------------------------------------------ */
	/* /ZPHP Generated Code ------------------------------------------ */

}

