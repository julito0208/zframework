<?php 

class IndexPageMobile extends MasterPageMobile implements AccessControlPublic {
	
	const URL_ID = 'IndexPage';
	
	public function __construct() {
		parent::__construct();
	}
	
	public function prepare_params() {
		parent::prepare_params();
	}
}