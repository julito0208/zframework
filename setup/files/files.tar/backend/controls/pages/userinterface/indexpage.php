<?php 

class IndexPage extends MasterPage implements AccessControlPublic {
	
	const URL_ID = 'IndexPage';
	
	public function __construct() {
		parent::__construct();
	}
	
	public function prepare_params() {
		parent::prepare_params();
	}
}