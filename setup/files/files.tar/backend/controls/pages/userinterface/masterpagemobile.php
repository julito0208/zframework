<?php 

class MasterPageMobile extends HTMLPageMobile {
	
	
	public function __construct() {
		parent::__construct();
	}
	
	public function prepare_params() {
		parent::prepare_params();
	}
}
