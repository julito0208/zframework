<?php 

$pages_redirects = array(
	array('/?(?:index(?:\.php)?)?', 'IndexPage'),
);
//
//$pages_redirects_mobile = array(
//	array('/?(?:index(?:\.php)?)?', 'IndexPageMobile'),
//);

/*-------------------------------------------------------------------------------------*/

RedirectControl::add_redirects($pages_redirects);
//RedirectControl::add_redirects_mobile($pages_redirects_mobile);
RedirectControl::redirect_process();